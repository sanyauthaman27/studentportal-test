package com.pages;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FeedbackPageTest {

    WebDriver driver;

    By studentNameBox = By.id("studentName");
    By ratingDropdown = By.id("rating");
    By commentsBox = By.id("comments");
    By confirmCheckbox = By.id("confirm");
    By submitButton = By.id("submitBtn");
    By messageBox = By.id("message");
    By pageTitle = By.id("pageTitle");

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        String path = new File("src/test/student portal/feedback.html")
                .getAbsolutePath();

        driver.get("file:///" + path.replace('\\', '/'));
    }

    public String getMessage() {
        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(5));

        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(messageBox))
                .getText();
    }

    @Test
    public void verifyStudentNamePlaceholder() {

        String placeholder =
                driver.findElement(studentNameBox)
                        .getAttribute("placeholder");

        Assert.assertEquals(
                placeholder,
                "Enter student name");
    }

    @Test
    public void verifyCommentsPlaceholder() {

        String placeholder =
                driver.findElement(commentsBox)
                        .getAttribute("placeholder");

        Assert.assertEquals(
                placeholder,
                "Enter your comments");
    }

    @Test
    public void verifyPageTitle() {

        Assert.assertEquals(
                driver.findElement(pageTitle).getText(),
                "Student Feedback Form");
    }

    @Test
    public void verifySubmitButtonDisplayed() {

        Assert.assertTrue(
                driver.findElement(submitButton).isDisplayed());
    }

    @Test
    public void verifyStudentNameRequired() {

        driver.findElement(submitButton).click();

        Assert.assertEquals(
                getMessage(),
                "Student name is required");
    }

    @Test
    public void verifyRatingRequired() {

        driver.findElement(studentNameBox)
                .sendKeys("Sanya");

        driver.findElement(submitButton).click();

        Assert.assertEquals(
                getMessage(),
                "Rating is required");
    }

    @Test
    public void verifyCommentsMinimumLength() {

        driver.findElement(studentNameBox)
                .sendKeys("Sanya");

        driver.findElement(ratingDropdown)
                .sendKeys("Excellent");

        driver.findElement(commentsBox)
                .sendKeys("Good");

        driver.findElement(submitButton).click();

        Assert.assertEquals(
                getMessage(),
                "Comments should be minimum 10 characters");
    }

    @Test
    public void verifyConfirmCheckboxRequired() {

        driver.findElement(studentNameBox)
                .sendKeys("Sanya");

        driver.findElement(ratingDropdown)
                .sendKeys("Excellent");

        driver.findElement(commentsBox)
                .sendKeys("Excellent course");

        driver.findElement(submitButton).click();

        Assert.assertEquals(
                getMessage(),
                "Please confirm your feedback");
    }

    @Test
    public void verifySuccessfulFeedbackSubmission() {

        driver.findElement(studentNameBox)
                .sendKeys("Sanya");

        driver.findElement(ratingDropdown)
                .sendKeys("Excellent");

        driver.findElement(commentsBox)
                .sendKeys("Excellent teaching and support");

        driver.findElement(confirmCheckbox)
                .click();

        driver.findElement(submitButton)
                .click();

        Assert.assertEquals(
                getMessage(),
                "Feedback submitted successfully");
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}