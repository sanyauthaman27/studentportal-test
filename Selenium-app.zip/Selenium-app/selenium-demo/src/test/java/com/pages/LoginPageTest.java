package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginPageTest {

    WebDriver driver;

    By usernameBox = By.id("username");
    By passwordBox = By.id("password");
    By loginButton = By.id("loginBtn");
    By messageBox = By.id("message");

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        String path = new java.io.File("src/test/student portal/index.html").getAbsolutePath();
        driver.get("file:///" + path.replace('\\', '/'));
    }

    public void enterUsername(String username) {
        driver.findElement(usernameBox).clear();
        driver.findElement(usernameBox).sendKeys(username);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordBox).clear();
        driver.findElement(passwordBox).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(loginButton).click();
    }

    public String getMessage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        return wait.until(ExpectedConditions.presenceOfElementLocated(messageBox)).getText();
    }

    @Test
    public void loginWithoutUsername() {

        clickLogin();

        Assert.assertEquals(
                getMessage(),
                "Username is required");
    }

    @Test
    public void invalidUsername() {
        // use an incorrect username to trigger the "Invalid username" message
        enterUsername("wronguser");
        enterPassword("Student@123");

        clickLogin();

        Assert.assertEquals(
                getMessage(),
                "Invalid username");
    }

    @Test
    public void invalidPassword() {

        enterUsername("student");
        enterPassword("student123");

        clickLogin();

        Assert.assertEquals(
                getMessage(),
                "Invalid password");
    }

    @Test
    public void validLogin() {

        enterUsername("student");
        enterPassword("Student@123");

        clickLogin();

        Assert.assertTrue(
                driver.getCurrentUrl().contains("dashboard"));
    }

    @AfterMethod
    public void tearDown() {

        driver.quit();
    }
}