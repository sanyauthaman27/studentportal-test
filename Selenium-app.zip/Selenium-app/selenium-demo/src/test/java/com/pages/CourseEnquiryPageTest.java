package com.pages;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CourseEnquiryPageTest {

    WebDriver driver;

    By studentName = By.id("studentName");
    By email = By.id("email");
    By mobile = By.id("mobile");
    By course = By.id("course");
    By online = By.id("online");
    By offline = By.id("offline");
    By submitBtn = By.id("submitBtn");
    By message = By.id("message");
    By pageTitle = By.id("pageTitle");

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();

        String path = new File(
                "src/test/student portal/course-enquiry.html")
                .getAbsolutePath();

        driver.get("file:///" + path.replace('\\', '/'));
    }

    public String getMessage() {

        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(5));

        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(message))
                .getText();
    }

    @Test
    public void verifyPageTitle() {

        Assert.assertEquals(
                driver.findElement(pageTitle).getText(),
                "Course Enquiry Form");
    }

    @Test
    public void verifyStudentNamePlaceholder() {

        Assert.assertEquals(
                driver.findElement(studentName)
                        .getAttribute("placeholder"),
                "Enter student name");
    }

    @Test
    public void verifyEmailPlaceholder() {

        Assert.assertEquals(
                driver.findElement(email)
                        .getAttribute("placeholder"),
                "Enter email");
    }

    @Test
    public void verifyMobilePlaceholder() {

        Assert.assertEquals(
                driver.findElement(mobile)
                        .getAttribute("placeholder"),
                "Enter mobile number");
    }

    @Test
    public void verifyStudentNameRequired() {

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Student name is required");
    }

    @Test
    public void verifyEmailRequired() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Email is required");
    }

    @Test
    public void verifyInvalidEmail() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya123");

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Invalid email format");
    }

    @Test
    public void verifyMobileValidation() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya@gmail.com");

        driver.findElement(mobile)
                .sendKeys("98765");

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Mobile number should be exactly 10 digits");
    }

    @Test
    public void verifyCourseRequired() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya@gmail.com");

        driver.findElement(mobile)
                .sendKeys("9876543210");

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Course is required");
    }

    @Test
    public void verifyLearningModeRequired() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya@gmail.com");

        driver.findElement(mobile)
                .sendKeys("9876543210");

        driver.findElement(course)
                .sendKeys("Java Full Stack");

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Learning mode is required");
    }

    @Test
    public void verifySuccessfulEnquiryOnline() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya@gmail.com");

        driver.findElement(mobile)
                .sendKeys("9876543210");

        driver.findElement(course)
                .sendKeys("Java Full Stack");

        driver.findElement(online).click();

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Course enquiry submitted successfully");
    }

    @Test
    public void verifySuccessfulEnquiryOffline() {

        driver.findElement(studentName)
                .sendKeys("Sanya");

        driver.findElement(email)
                .sendKeys("sanya@gmail.com");

        driver.findElement(mobile)
                .sendKeys("9876543210");

        driver.findElement(course)
                .sendKeys("Python Data Science");

        driver.findElement(offline).click();

        driver.findElement(submitBtn).click();

        Assert.assertEquals(
                getMessage(),
                "Course enquiry submitted successfully");
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}
