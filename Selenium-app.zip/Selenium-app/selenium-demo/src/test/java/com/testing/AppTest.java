package com.testing;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AppTest {

    private String getMessage(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message"))).getText();
    }

    @Test
    public void testLoginWithoutUsername() {
        WebDriver driver = new ChromeDriver();
        try {
            String path = new java.io.File("src/test/student portal/index.html").getAbsolutePath();
            driver.get("file:///" + path.replace('\\', '/'));
            driver.findElement(By.id("loginBtn")).click();
            String actualMessage = getMessage(driver);
            Assert.assertEquals(actualMessage, "Username is required");
        } finally {
            driver.quit();
        }
    }

    @Test
    public void testInvalidUsername() {
        WebDriver driver = new ChromeDriver();
        try {
            String path = new java.io.File("src/test/student portal/index.html").getAbsolutePath();
            driver.get("file:///" + path.replace('\\', '/'));
            driver.findElement(By.id("username")).clear();
            driver.findElement(By.id("username")).sendKeys("wronguser");
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys("Student@123");
            driver.findElement(By.id("loginBtn")).click();
            String actualMessage = getMessage(driver);
            Assert.assertEquals(actualMessage, "Invalid username");
        } finally {
            driver.quit();
        }
    }

    @Test
    public void testInvalidPassword() {
        WebDriver driver = new ChromeDriver();
        try {
            String path = new java.io.File("src/test/student portal/index.html").getAbsolutePath();
            driver.get("file:///" + path.replace('\\', '/'));
            driver.findElement(By.id("username")).clear();
            driver.findElement(By.id("username")).sendKeys("student");
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys("student123");
            driver.findElement(By.id("loginBtn")).click();
            String actualMessage = getMessage(driver);
            Assert.assertEquals(actualMessage, "Invalid password");
        } finally {
            driver.quit();
        }
    }
}